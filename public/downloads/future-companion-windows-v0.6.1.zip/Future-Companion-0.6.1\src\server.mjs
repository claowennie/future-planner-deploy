import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  executeMusicAction,
  getPlayerState,
  isAllowedAction,
  NcmCliError,
  resolveNcmCliEntry,
} from './ncm-cli.mjs';

const HOST = '127.0.0.1';
const PORT = Number(process.env.FUTURE_COMPANION_PORT || 45731);
const MAX_BODY_BYTES = 16 * 1024;
const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DEFAULT_ORIGINS = [
  'https://future-planner.claireeek.com',
  'https://future-planner.claowennie.workers.dev',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
];

function configPath() {
  return path.join(PROJECT_ROOT, '.future-companion', 'config.json');
}

function loadPairingToken() {
  const fromEnv = String(process.env.FUTURE_COMPANION_TOKEN || '').trim();
  if (fromEnv.length >= 24) return fromEnv;
  const target = configPath();
  try {
    const stored = JSON.parse(fs.readFileSync(target, 'utf8'));
    if (typeof stored.token === 'string' && stored.token.length >= 24) return stored.token;
  } catch { /* create a local token below */ }
  const token = crypto.randomBytes(24).toString('hex');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, `${JSON.stringify({ token }, null, 2)}\n`, { mode: 0o600 });
  return token;
}

const token = loadPairingToken();
const allowedOrigins = new Set([
  ...DEFAULT_ORIGINS,
  ...String(process.env.FUTURE_COMPANION_ORIGINS || '').split(',').map((item) => item.trim()).filter(Boolean),
]);

function originAllowed(origin) {
  return !origin || allowedOrigins.has(origin);
}

function responseHeaders(origin) {
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Access-Control-Allow-Origin': origin || 'null',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Future-Companion-Token',
    'Access-Control-Allow-Private-Network': 'true',
    Vary: 'Origin, Access-Control-Request-Private-Network',
  };
}

function sendJson(response, origin, status, body) {
  response.writeHead(status, responseHeaders(origin));
  response.end(JSON.stringify(body));
}

function tokenMatches(candidate) {
  const supplied = Buffer.from(String(candidate || ''));
  const expected = Buffer.from(token);
  return supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
}

function readJsonBody(request) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let raw = '';
    request.setEncoding('utf8');
    request.on('data', (chunk) => {
      size += Buffer.byteLength(chunk);
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('请求内容过大'), { status: 413 }));
        request.destroy();
        return;
      }
      raw += chunk;
    });
    request.on('end', () => {
      try { resolve(JSON.parse(raw || '{}')); }
      catch { reject(Object.assign(new Error('请求 JSON 格式错误'), { status: 400 })); }
    });
    request.on('error', reject);
  });
}

const server = http.createServer(async (request, response) => {
  const origin = request.headers.origin || '';
  if (!originAllowed(origin)) {
    sendJson(response, '', 403, { error: '不允许这个网页访问本机桥' });
    return;
  }
  if (request.method === 'OPTIONS') {
    response.writeHead(204, responseHeaders(origin));
    response.end();
    return;
  }
  if (!tokenMatches(request.headers['x-future-companion-token'])) {
    sendJson(response, origin, 401, { error: '本机配对码不正确' });
    return;
  }

  const url = new URL(request.url || '/', `http://${HOST}:${PORT}`);
  if (request.method === 'GET' && url.pathname === '/health') {
    try {
      resolveNcmCliEntry();
      sendJson(response, origin, 200, {
        ok: true,
        service: 'future-companion',
        version: '0.6.1',
        provider: 'netease-ncm-cli',
      });
    } catch (error) {
      sendJson(response, origin, 503, { error: error.message, code: error.code || 'ncm_cli_missing' });
    }
    return;
  }

  if (request.method === 'GET' && url.pathname === '/state') {
    try {
      sendJson(response, origin, 200, { ok: true, state: await getPlayerState() });
    } catch (error) {
      sendJson(response, origin, 422, { error: error.message, code: error.code || 'player_state_error' });
    }
    return;
  }

  if (request.method === 'POST' && url.pathname === '/command') {
    try {
      const body = await readJsonBody(request);
      const action = String(body.action || '').trim();
      if (!isAllowedAction(action)) {
        sendJson(response, origin, 422, { error: '不支持这个播放指令', code: 'unsupported_action' });
        return;
      }
      const result = await executeMusicAction(action, body.query, body.queries, {
        position: body.position,
        volume: body.volume,
        index: body.index,
        selections: body.selections,
        deferPlayback: body.deferPlayback === true,
      });
      sendJson(response, origin, 200, result);
    } catch (error) {
      const status = error.status || (error instanceof NcmCliError ? 422 : 500);
      sendJson(response, origin, status, {
        error: error instanceof NcmCliError ? error.message : '本机桥执行失败',
        code: error.code || 'companion_error',
      });
    }
    return;
  }

  sendJson(response, origin, 404, { error: 'Not found' });
});

server.listen(PORT, HOST, () => {
  console.log('');
  console.log(`Future Companion 已启动：http://${HOST}:${PORT}`);
  console.log(`本机配对码：${token}`);
  console.log('请保持这个窗口开启，然后把配对码粘贴到 Future → Melo → 设置。');
  console.log('按 Ctrl+C 停止。');
  console.log('');
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`端口 ${PORT} 已被占用。Future Companion 可能已经启动，请先关闭旧窗口后重试。`);
  } else {
    console.error(`Future Companion 启动失败：${error.message}`);
  }
  process.exitCode = 1;
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
