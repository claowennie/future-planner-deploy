@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Future Companion Setup

echo ============================================================
echo Future Companion 首次安装 / First-time setup
echo ============================================================
echo.

where node.exe >nul 2>nul
if errorlevel 1 goto node_missing

set "NODE_MAJOR="
for /f %%V in ('node -p "process.versions.node.split('.')[0]"') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR goto node_missing
if %NODE_MAJOR% LSS 18 goto node_old

where npm.cmd >nul 2>nul
if errorlevel 1 goto npm_missing

echo [1/4] Installing the official NetEase ncm-cli component...
echo       正在安装网易云官方 ncm-cli 组件……
call npm.cmd install --global @music163/ncm-cli@0.1.6
if errorlevel 1 goto install_failed

if exist "C:\Program Files\MPV Player\mpv.exe" set "PATH=C:\Program Files\MPV Player;%PATH%"
where mpv.exe >nul 2>nul
if errorlevel 1 goto mpv_missing

echo.
echo [2/4] Configure NetEase Open Platform credentials.
echo       请按提示填写网易云音乐开放平台的 App ID 与 Private Key。
echo       Setup reference: https://www.npmjs.com/package/@music163/ncm-cli
echo.
node "src\setup.mjs" configure
if errorlevel 1 goto configure_failed

echo.
echo [3/4] Sign in to NetEase Cloud Music with the QR code.
echo       请用网易云音乐 App 扫码登录。
echo.
node "src\setup.mjs" login
if errorlevel 1 goto login_failed

echo.
echo [4/4] Verifying sign-in...
node "src\setup.mjs" check
if errorlevel 1 goto login_failed

echo.
echo ============================================================
echo Setup complete / 安装完成
echo 现在双击 start-companion.cmd，并把窗口中的配对码粘贴到：
echo Future website ^> Melo ^> Settings ^> NetEase desktop companion
echo Keep the companion window open while Melo is playing music.
echo ============================================================
echo.
pause
exit /b 0

:node_missing
echo Node.js was not found / 未找到 Node.js。
echo Install Node.js 18 or later: https://nodejs.org/en/download
goto failed

:node_old
echo Node.js %NODE_MAJOR% is too old / Node.js %NODE_MAJOR% 版本过旧。
echo Install Node.js 18 or later: https://nodejs.org/en/download
goto failed

:npm_missing
echo npm was not found. Reinstall Node.js with npm enabled.
echo 未找到 npm，请重新安装 Node.js 并保留 npm 组件。
goto failed

:install_failed
echo Could not install @music163/ncm-cli. Check the network and try again.
echo 网易云组件安装失败，请检查网络后重试。
goto failed

:mpv_missing
echo mpv was not found / 未找到 mpv 播放器。
echo Install mpv, then run this setup again: https://mpv.io/installation/
start "" "https://mpv.io/installation/"
goto failed

:configure_failed
echo NetEase Open Platform configuration was not completed.
echo 网易云开放平台配置未完成，请检查 App ID 与 Private Key 后重试。
goto failed

:login_failed
echo NetEase sign-in was not completed. Run this setup again when ready.
echo 网易云登录未完成，准备好后重新运行本安装脚本。
goto failed

:failed
echo.
pause
exit /b 1
