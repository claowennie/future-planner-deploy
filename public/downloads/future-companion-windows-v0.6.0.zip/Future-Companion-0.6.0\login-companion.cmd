@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Future Companion - NetEase Login

where node.exe >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Run setup-companion.cmd first.
  echo 未找到 Node.js，请先运行 setup-companion.cmd。
  pause
  exit /b 1
)

echo Scan the QR code with the NetEase Cloud Music app.
echo 请使用网易云音乐 App 扫码登录。
echo.
node "src\setup.mjs" login
if errorlevel 1 (
  echo.
  echo Login was not completed / 登录未完成。
  pause
  exit /b 1
)

echo.
node "src\setup.mjs" check
if errorlevel 1 (
  echo Login verification failed / 登录验证失败。
  pause
  exit /b 1
)

echo Login complete. Restart Future Companion if it is already open.
echo 登录完成。如果 Future Companion 已开启，请关闭后重新启动。
pause
