@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Future Companion

where node.exe >nul 2>nul
if errorlevel 1 (
  echo [Future Companion] Node.js was not found.
  echo 请先安装 Node.js 18 或更新版本，然后重新运行本文件。
  echo Install Node.js 18 or later, then run this file again.
  echo https://nodejs.org/en/download
  echo.
  pause
  exit /b 1
)

if exist "C:\Program Files\MPV Player\mpv.exe" set "PATH=C:\Program Files\MPV Player;%PATH%"

node "src\setup.mjs" locate >nul 2>nul
if errorlevel 1 (
  echo [Future Companion] 网易云音乐组件尚未安装。
  echo The NetEase music component is not installed yet.
  echo 请先双击 setup-companion.cmd 完成首次安装。
  echo Run setup-companion.cmd once before starting the companion.
  echo.
  pause
  exit /b 1
)

node "src\server.mjs"
echo.
echo Future Companion stopped. Press any key to close.
pause >nul
