import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;
const PASSTHROUGH_CONTROL_ACTIONS = new Map([
  ['pause', 'pause'],
  ['resume', 'resume'],
]);
const READ_ACTIONS = new Set(['list_playlists', 'taste_sample']);
const LOGIN_REQUIRED_ACTIONS = new Set(['list_playlists', 'taste_sample', 'play_daily', 'search_and_play']);
const LOGIN_CHECK_CACHE_MS = 30_000;
let queueBuildPromise = Promise.resolve();
let activeTrackSet = [];
let activeTrackIndex = -1;
let activeTrackPrepared = false;
let activeVolume = null;
let lastSuccessfulLoginCheckAt = 0;

export class NcmCliError extends Error {
  constructor(message, code = 'ncm_cli_error') {
    super(message);
    this.name = 'NcmCliError';
    this.code = code;
  }
}

function packageCandidates() {
  const candidates = [];
  if (process.env.NCM_CLI_PACKAGE_JSON) candidates.push(process.env.NCM_CLI_PACKAGE_JSON);
  if (process.env.APPDATA) {
    candidates.push(path.join(
      process.env.APPDATA,
      'npm', 'node_modules', '@music163', 'ncm-cli', 'package.json',
    ));
  }
  if (process.env.npm_config_prefix) {
    candidates.push(path.join(
      process.env.npm_config_prefix,
      'node_modules', '@music163', 'ncm-cli', 'package.json',
    ));
    candidates.push(path.join(
      process.env.npm_config_prefix,
      'lib', 'node_modules', '@music163', 'ncm-cli', 'package.json',
    ));
  }
  return [...new Set(candidates.map((item) => path.resolve(item)))];
}

export function resolveNcmCliEntry() {
  if (process.env.NCM_CLI_ENTRY) {
    const explicit = path.resolve(process.env.NCM_CLI_ENTRY);
    if (fs.existsSync(explicit)) return explicit;
  }

  for (const packageJsonPath of packageCandidates()) {
    if (!fs.existsSync(packageJsonPath)) continue;
    try {
      const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
      const bin = typeof pkg.bin === 'string'
        ? pkg.bin
        : (pkg.bin?.['ncm-cli'] || Object.values(pkg.bin || {})[0]);
      if (!bin) continue;
      const entry = path.resolve(path.dirname(packageJsonPath), bin);
      if (fs.existsSync(entry)) return entry;
    } catch { /* try the next known global npm location */ }
  }

  throw new NcmCliError(
    '找不到 @music163/ncm-cli。请先运行 npm install -g @music163/ncm-cli，或设置 NCM_CLI_ENTRY。',
    'ncm_cli_missing',
  );
}

export function runNcmCli(args, { timeoutMs = 30000 } = {}) {
  if (!Array.isArray(args) || args.some((item) => typeof item !== 'string' || item.includes('\0'))) {
    return Promise.reject(new NcmCliError('CLI 参数无效', 'invalid_cli_args'));
  }
  const entry = resolveNcmCliEntry();
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [entry, ...args], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1' },
    });
    let stdout = '';
    let stderr = '';
    let outputBytes = 0;
    let settled = false;
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      callback();
    };
    const append = (current, chunk) => {
      outputBytes += chunk.length;
      if (outputBytes > MAX_OUTPUT_BYTES) {
        child.kill();
        finish(() => reject(new NcmCliError('网易云 CLI 返回内容过大', 'ncm_cli_output_too_large')));
        return current;
      }
      return current + chunk.toString('utf8');
    };
    child.stdout.on('data', (chunk) => { stdout = append(stdout, chunk); });
    child.stderr.on('data', (chunk) => { stderr = append(stderr, chunk); });
    child.on('error', (error) => finish(() => reject(new NcmCliError(`无法启动网易云 CLI：${error.message}`))));
    child.on('close', (code) => finish(() => {
      if (code === 0) resolve(stdout.trim());
      else {
        const detail = String(stderr || stdout || `退出码 ${code}`).trim().slice(0, 600);
        reject(new NcmCliError(`网易云 CLI 执行失败：${detail}`, 'ncm_cli_failed'));
      }
    }));
    const timer = setTimeout(() => {
      child.kill();
      finish(() => reject(new NcmCliError('网易云 CLI 响应超时', 'ncm_cli_timeout')));
    }, timeoutMs);
  });
}

export function parseCliJson(output) {
  const clean = String(output || '').replace(/\u001b\[[0-9;]*m/g, '').trim();
  try { return JSON.parse(clean); }
  catch { throw new NcmCliError('网易云 CLI 返回了无法识别的数据', 'invalid_ncm_json'); }
}

export function isNcmLoginActive(payload) {
  return payload?.success === true;
}

async function assertNcmLoggedIn({ force = false } = {}) {
  if (!force && Date.now() - lastSuccessfulLoginCheckAt < LOGIN_CHECK_CACHE_MS) return;
  const payload = parseCliJson(await runNcmCli(['login', '--check', '--output', 'json']));
  if (!isNcmLoginActive(payload)) {
    throw new NcmCliError(
      '网易云登录已过期。请在终端运行 ncm-cli login 重新扫码，然后重启 Future Companion。',
      'ncm_login_required',
    );
  }
  lastSuccessfulLoginCheckAt = Date.now();
}

export function normalizePlaybackVolume(value) {
  const volume = Number(value);
  if (!Number.isFinite(volume) || volume < 0 || volume > 100) {
    throw new NcmCliError('音量必须是 0 到 100 之间的数字', 'invalid_volume');
  }
  return Math.round(volume);
}

function playableRecords(payload) {
  const data = payload?.data;
  const records = Array.isArray(data) ? data : data?.records;
  if (!Array.isArray(records)) return [];
  return records.filter((track) => (
    track && track.playFlag === true && track.visible !== false
    && /^[A-Fa-f0-9]{32}$/.test(String(track.id || ''))
    && /^\d+$/.test(String(track.originalId || ''))
  ));
}

export function normalizeTrackKey(value) {
  return String(value || '').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
}

function splitArtists(value) {
  const source = Array.isArray(value)
    ? value.map((artist) => typeof artist === 'string' ? artist : artist?.name).join('/')
    : String(value || '');
  return source.split(/[\/、,，&]+/).map(normalizeTrackKey).filter(Boolean);
}

const CJK = /[\p{sc=Han}\p{sc=Hiragana}\p{sc=Katakana}\p{sc=Hangul}]/u;

function softEqualArtist(wanted, candidate) {
  if (!wanted || !candidate) return false;
  if (candidate === wanted) return true;
  if (candidate.includes(wanted)) return !CJK.test(candidate.split(wanted).join(''));
  if (wanted.includes(candidate)) return !CJK.test(wanted.split(candidate).join(''));
  return false;
}

// Ported from future.v2's Claudio matching rule: every named artist must match,
// otherwise the result is skipped instead of playing a same-title cover account.
export function cleanArtistMatch(wantedArtist, candidateArtists) {
  const wanted = splitArtists(wantedArtist);
  if (!wanted.length) return true;
  const candidates = splitArtists(candidateArtists);
  if (!candidates.length) return false;
  return wanted.every((artist) => candidates.some((candidate) => softEqualArtist(artist, candidate)))
    && candidates.every((candidate) => wanted.some((artist) => softEqualArtist(artist, candidate)));
}

export function titleHit(wantedTitle, candidateTitle) {
  const wanted = normalizeTrackKey(wantedTitle);
  const candidate = normalizeTrackKey(candidateTitle);
  if (!wanted || !candidate) return true;
  return candidate.includes(wanted) || wanted.includes(candidate);
}

const VARIANT_MARKERS = /(翻唱|cover|remix|dj|伴奏|纯音乐|加速|降速|sped\s*up|slowed|片段|热播|男声版|女声版)/i;

function isUnexpectedVariant(wantedTitle, candidateTitle) {
  return VARIANT_MARKERS.test(String(candidateTitle || ''))
    && !VARIANT_MARKERS.test(String(wantedTitle || ''));
}

export function selectPlayableTrack(payload, expected = {}) {
  const records = playableRecords(payload);
  if (!records.length) return null;
  const wantedTitle = String(expected?.title || '').trim();
  const wantedArtist = String(expected?.artist || '').trim();
  if (!wantedTitle && !wantedArtist) return records[0];

  const matches = records.filter((track) => (
    cleanArtistMatch(wantedArtist, track.artists)
    && titleHit(wantedTitle, track.name)
  ));
  if (!matches.length) return null;
  const exactTitle = matches.find((track) => (
    normalizeTrackKey(track.name) === normalizeTrackKey(wantedTitle)
  ));
  if (exactTitle) return exactTitle;
  return matches.find((track) => !isUnexpectedVariant(wantedTitle, track.name)) || matches[0];
}

export function selectPlayableTracks(payload, limit = 5) {
  const data = payload?.data;
  const records = Array.isArray(data) ? data : data?.records;
  if (!Array.isArray(records)) return [];
  const seen = new Set();
  return records.filter((track) => {
    const id = String(track?.id || '');
    if (!track || track.playFlag !== true || track.visible === false
      || !/^[A-Fa-f0-9]{32}$/.test(id) || !/^\d+$/.test(String(track.originalId || ''))
      || seen.has(id)) return false;
    seen.add(id);
    return true;
  }).slice(0, Math.max(1, Math.min(Number(limit) || 5, 8)));
}

function publicTrack(track) {
  return {
    name: String(track.name || '').slice(0, 160),
    artists: Array.isArray(track.artists)
      ? track.artists.map((artist) => String(artist?.name || '').slice(0, 120)).filter(Boolean).slice(0, 5)
      : [],
  };
}

function publicTasteTrack(track) {
  return {
    title: String(track?.name || track?.song?.name || '').trim().slice(0, 160),
    artist: (Array.isArray(track?.artists) ? track.artists : track?.song?.artists || [])
      .map((artist) => String(artist?.name || '').trim()).filter(Boolean).slice(0, 5).join(' / ').slice(0, 220),
  };
}

export function selectPublicPlaylists(payload, source = 'created') {
  const records = Array.isArray(payload?.data) ? payload.data : payload?.data?.records;
  if (!Array.isArray(records)) return [];
  return records.map((playlist) => ({
    id: String(playlist?.id || ''),
    name: String(playlist?.name || '').trim().slice(0, 160),
    trackCount: Math.max(0, Number(playlist?.trackCount) || 0),
    source,
  })).filter((playlist) => /^[A-Fa-f0-9]{32}$/.test(playlist.id) && playlist.name);
}

async function playTrack(track) {
  await runNcmCli([
    'play', '--song',
    '--encrypted-id', String(track.id),
    '--original-id', String(track.originalId),
    '--output', 'json',
  ], { timeoutMs: 45000 });
  if (activeVolume !== null) {
    try { await runNcmCli(['volume', String(activeVolume)]); }
    catch { /* playback succeeded; a volume sync failure must not stop the song */ }
  }
  return publicTrack(track);
}

async function addTrackToQueue(track) {
  await runNcmCli([
    'queue', 'add',
    '--encrypted-id', String(track.id),
    '--original-id', String(track.originalId),
    '--output', 'json',
  ]);
  return publicTrack(track);
}

async function clearPlaybackQueue() {
  await runNcmCli(['queue', 'clear', '--output', 'json']);
}

async function prepareTrackSet(tracks) {
  if (!tracks.length) throw new NcmCliError('没有找到当前账号可播放的匹配歌曲', 'no_playable_track');
  // A previous recommendation may still be adding tracks in the background.
  // Finish that small job first, then clear it in one place so old songs can
  // never leak into the new set.
  await queueBuildPromise.catch(() => {});
  try { await runNcmCli(['pause']); } catch { /* a stopped player is already paused */ }
  await clearPlaybackQueue();
  const publicTracks = tracks.map(publicTrack);
  // Search recommendations stay in the companion, one track at a time. This
  // lets the web radio wait for a true song end, speak, then explicitly start
  // the next track instead of interrupting the final seconds.
  activeTrackSet = tracks.slice();
  activeTrackIndex = 0;
  activeTrackPrepared = true;
  return publicTracks;
}

async function playTrackSet(tracks) {
  const publicTracks = await prepareTrackSet(tracks);
  await playTrack(tracks[0]);
  activeTrackPrepared = false;
  return publicTracks;
}

async function playNativeTrackSet(tracks) {
  if (!tracks.length) throw new NcmCliError('没有找到当前账号可播放的匹配歌曲', 'no_playable_track');
  await queueBuildPromise.catch(() => {});
  await clearPlaybackQueue();
  activeTrackSet = [];
  activeTrackIndex = -1;
  activeTrackPrepared = false;
  const publicTracks = tracks.map(publicTrack);
  await playTrack(tracks[0]);
  queueBuildPromise = (async () => {
    for (const track of tracks.slice(1)) {
      try { await addTrackToQueue(track); }
      catch { /* an unavailable follow-up song must not interrupt playback */ }
    }
  })();
  return publicTracks;
}

function splitStateTitle(value) {
  const text = String(value || '').trim();
  const separator = text.lastIndexOf(' - ');
  if (separator < 1) return { title: text, artist: '' };
  return { title: text.slice(0, separator), artist: text.slice(separator + 3) };
}

function stoppedPlayerState() {
  return {
    status: 'stopped',
    title: '',
    artist: '',
    position: 0,
    duration: 0,
    progress: '',
    currentIndex: null,
    queueLength: 0,
  };
}

function preparedPlayerState() {
  const track = activeTrackSet[activeTrackIndex];
  if (!activeTrackPrepared || !track || activeTrackIndex < 0) return null;
  const current = publicTrack(track);
  return {
    status: 'paused',
    title: current.name,
    artist: current.artists.join(' / '),
    position: 0,
    duration: 0,
    progress: '',
    currentIndex: activeTrackIndex,
    queueLength: activeTrackSet.length,
  };
}

function withActiveTrackSet(state) {
  const track = activeTrackSet[activeTrackIndex];
  if (!track || activeTrackIndex < 0) return state;
  const current = publicTrack(track);
  return {
    ...state,
    title: current.name,
    artist: current.artists.join(' / '),
    currentIndex: activeTrackIndex,
    queueLength: activeTrackSet.length,
  };
}

export function isPlayerDaemonRunning() {
  const pidPath = process.env.NCM_CLI_DAEMON_PID
    || path.join(os.homedir(), '.config', 'ncm-cli', 'daemon.pid');
  try {
    const pid = Number.parseInt(fs.readFileSync(pidPath, 'utf8').trim(), 10);
    if (!Number.isInteger(pid) || pid < 1) return false;
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === 'EPERM';
  }
}

export async function getPlayerState() {
  const prepared = preparedPlayerState();
  if (prepared) return prepared;
  // `ncm-cli state` starts its daemon when none exists. On Windows, repeatedly
  // starting a daemon only to report "stopped" can hit a libuv shutdown
  // assertion. Treat an absent daemon as the authoritative stopped state.
  if (!isPlayerDaemonRunning()) return withActiveTrackSet(stoppedPlayerState());
  const payload = parseCliJson(await runNcmCli(['state']));
  const state = payload?.state || {};
  const metadata = splitStateTitle(state.title);
  return withActiveTrackSet({
    status: ['playing', 'paused', 'stopped'].includes(state.status) ? state.status : 'unknown',
    title: metadata.title.slice(0, 160),
    artist: metadata.artist.slice(0, 160),
    position: Number.isFinite(Number(state.position)) ? Math.max(0, Number(state.position)) : 0,
    duration: Number.isFinite(Number(state.duration)) ? Math.max(0, Number(state.duration)) : 0,
    progress: String(state.progress || '').slice(0, 40),
    currentIndex: Number.isInteger(state.currentIndex) ? state.currentIndex : null,
    queueLength: Number.isInteger(state.queueLength) ? state.queueLength : 0,
  });
}

// The play command can finish before mpv publishes its new state. Polling here
// keeps command responses aligned with the audio users can already hear.
export async function waitForPlayerStart(readState = getPlayerState, {
  attempts = 8,
  delayMs = 120,
} = {}) {
  const total = Math.max(1, Math.min(Number(attempts) || 1, 20));
  const delay = Math.max(0, Math.min(Number(delayMs) || 0, 1000));
  let state = null;
  for (let attempt = 0; attempt < total; attempt += 1) {
    state = await readState();
    if (state?.status === 'playing') return state;
    if (attempt + 1 < total && delay > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  return state;
}

async function stopPlayback() {
  await runNcmCli(['stop']);
  activeTrackSet = [];
  activeTrackIndex = -1;
  activeTrackPrepared = false;
  return stoppedPlayerState();
}

async function stepActiveTrackSet(action) {
  if (!activeTrackSet.length || activeTrackIndex < 0) {
    await runNcmCli([action === 'previous' ? 'prev' : 'next']);
    return { track: null, state: await getPlayerState() };
  }
  const targetIndex = activeTrackIndex + (action === 'previous' ? -1 : 1);
  if (targetIndex < 0 || targetIndex >= activeTrackSet.length) {
    return { track: publicTrack(activeTrackSet[activeTrackIndex]), state: await getPlayerState() };
  }
  await clearPlaybackQueue();
  await playTrack(activeTrackSet[targetIndex]);
  activeTrackIndex = targetIndex;
  activeTrackPrepared = false;
  return { track: publicTrack(activeTrackSet[targetIndex]), state: await waitForPlayerStart() };
}

async function prepareActiveTrackAt(index) {
  const targetIndex = Number(index);
  if (!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= activeTrackSet.length) {
    throw new NcmCliError('歌单中的歌曲位置无效', 'invalid_track_index');
  }
  await queueBuildPromise.catch(() => {});
  try { await runNcmCli(['pause']); } catch { /* a stopped player is already paused */ }
  await clearPlaybackQueue();
  activeTrackIndex = targetIndex;
  activeTrackPrepared = true;
  return { track: publicTrack(activeTrackSet[targetIndex]), state: preparedPlayerState() };
}

async function playActiveTrackAt(index) {
  const targetIndex = Number(index);
  if (!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= activeTrackSet.length) {
    throw new NcmCliError('歌单中的歌曲位置无效', 'invalid_track_index');
  }
  await queueBuildPromise.catch(() => {});
  await clearPlaybackQueue();
  await playTrack(activeTrackSet[targetIndex]);
  activeTrackIndex = targetIndex;
  activeTrackPrepared = false;
  return { track: publicTrack(activeTrackSet[targetIndex]), state: await waitForPlayerStart() };
}

export async function executeMusicAction(action, query = '', queries = [], options = {}) {
  if (options.volume !== undefined) activeVolume = normalizePlaybackVolume(options.volume);
  if (LOGIN_REQUIRED_ACTIONS.has(action)) await assertNcmLoggedIn();

  if (action === 'resume' && activeTrackPrepared) {
    const result = await playActiveTrackAt(activeTrackIndex);
    return { ok: true, action, ...result };
  }
  if (action === 'pause' && activeTrackPrepared) {
    return { ok: true, action, track: publicTrack(activeTrackSet[activeTrackIndex]), state: preparedPlayerState() };
  }
  if (PASSTHROUGH_CONTROL_ACTIONS.has(action)) {
    await runNcmCli([PASSTHROUGH_CONTROL_ACTIONS.get(action)]);
    let state = null;
    try {
      state = action === 'resume' ? await waitForPlayerStart() : await getPlayerState();
    } catch { /* player may have just stopped */ }
    return { ok: true, action, state };
  }

  if (action === 'stop') {
    return { ok: true, action, state: await stopPlayback() };
  }

  if (action === 'next' || action === 'previous') {
    const result = await stepActiveTrackSet(action);
    return { ok: true, action, ...result };
  }

  if (action === 'play_index') {
    const result = await playActiveTrackAt(options.index);
    return { ok: true, action, ...result };
  }

  if (action === 'prepare_index') {
    const result = await prepareActiveTrackAt(options.index);
    return { ok: true, action, ...result };
  }

  if (action === 'seek') {
    const position = Number(options.position);
    if (!Number.isFinite(position) || position < 0 || position > 24 * 60 * 60) {
      throw new NcmCliError('播放进度无效', 'invalid_seek_position');
    }
    await runNcmCli(['seek', String(Math.round(position))]);
    return { ok: true, action, state: await getPlayerState() };
  }

  if (action === 'volume') {
    const volume = normalizePlaybackVolume(options.volume);
    activeVolume = volume;
    await runNcmCli(['volume', String(volume)]);
    return { ok: true, action, volume };
  }

  if (action === 'list_playlists') {
    const [created, collected] = await Promise.all([
      runNcmCli(['playlist', 'created', '--limit', '100', '--output', 'json'])
        .then(parseCliJson).catch(() => ({ data: [] })),
      runNcmCli(['playlist', 'collected', '--limit', '100', '--output', 'json'])
        .then(parseCliJson).catch(() => ({ data: [] })),
    ]);
    const seen = new Set();
    const playlists = [
      ...selectPublicPlaylists(created, 'created'),
      ...selectPublicPlaylists(collected, 'collected'),
    ].filter((playlist) => {
      if (seen.has(playlist.id)) return false;
      seen.add(playlist.id);
      return true;
    }).slice(0, 120);
    return { ok: true, action, playlists };
  }

  if (action === 'taste_sample') {
    const playlistIds = (Array.isArray(queries) ? queries : [])
      .map((item) => String(item || '').trim()).filter(Boolean).slice(0, 3);
    if (!playlistIds.length || playlistIds.some((id) => !/^[A-Fa-f0-9]{32}$/.test(id))) {
      throw new NcmCliError('请选择 1 到 3 个有效歌单', 'invalid_playlist_ids');
    }
    const payloads = await Promise.all(playlistIds.map((id) => runNcmCli([
      'playlist', 'tracks', '--playlistId', id, '--limit', '80', '--output', 'json',
    ], { timeoutMs: 45000 }).then(parseCliJson)));
    const seen = new Set();
    const tracks = payloads.flatMap((payload) => (
      Array.isArray(payload?.data) ? payload.data : payload?.data?.records || []
    )).map(publicTasteTrack).filter((track) => {
      const key = `${track.title.toLowerCase()}\n${track.artist.toLowerCase()}`;
      if (!track.title || seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 120);
    if (tracks.length < 3) throw new NcmCliError('所选歌单中可用于分析的歌曲太少', 'taste_sample_too_small');
    return { ok: true, action, tracks, playlistCount: playlistIds.length };
  }

  if (action === 'play_daily') {
    const payload = parseCliJson(await runNcmCli(['recommend', 'daily', '--limit', '20']));
    const tracks = selectPlayableTracks(payload, 10);
    if (!tracks.length) {
      await assertNcmLoggedIn({ force: true });
      throw new NcmCliError('今天的推荐里暂时没有可播放曲目', 'no_playable_track');
    }
    const publicTracks = await playNativeTrackSet(tracks);
    return { ok: true, action, track: publicTracks[0], tracks: publicTracks };
  }

  if (action === 'search_and_play') {
    const requested = (Array.isArray(options.selections) ? options.selections : [])
      .slice(0, 10)
      .map((item) => ({
        query: String(item?.query || '').trim(),
        title: String(item?.title || '').trim(),
        artist: String(item?.artist || '').trim(),
      }))
      .filter((item) => item.query || item.title);
    if (!requested.length) {
      requested.push(...(Array.isArray(queries) ? queries : [])
        .map((item) => ({ query: String(item || '').trim(), title: '', artist: '' }))
        .filter((item) => item.query).slice(0, 10));
    }
    if (!requested.length && String(query || '').trim()) {
      requested.push({ query: String(query).trim(), title: '', artist: '' });
    }
    if (!requested.length || requested.some((item) => (
      item.query.length > 120 || item.title.length > 160 || item.artist.length > 220
    ))) {
      throw new NcmCliError('请提供 1 到 10 条歌曲或歌手搜索词', 'invalid_search_query');
    }
    const found = await Promise.all(requested.map(async (selection) => {
      const keyword = selection.query || [selection.title, selection.artist].filter(Boolean).join(' ');
      try {
        const payload = parseCliJson(await runNcmCli([
          'search', 'song', '--keyword', keyword, '--limit', '20',
        ]));
        return {
          query: selection.query || keyword,
          track: selectPlayableTrack(payload, { title: selection.title, artist: selection.artist }),
        };
      } catch { return { query: keyword, track: null }; }
    }));
    const seen = new Set();
    const matches = found.filter(({ track }) => {
      const id = String(track?.id || '');
      if (!id || seen.has(id)) return false;
      seen.add(id);
      return true;
    });
    const tracks = matches.map(({ track }) => track);
    if (!tracks.length) await assertNcmLoggedIn({ force: true });
    const publicTracks = options.deferPlayback === true
      ? await prepareTrackSet(tracks) : await playTrackSet(tracks);
    const matchedTracks = publicTracks.map((track, index) => ({
      ...track,
      query: matches[index].query,
    }));
    return {
      ok: true,
      action,
      track: matchedTracks[0],
      tracks: matchedTracks,
      ...(options.deferPlayback === true ? { state: preparedPlayerState() } : {}),
    };
  }

  throw new NcmCliError('不支持这个播放指令', 'unsupported_action');
}

export function isAllowedAction(action) {
  return PASSTHROUGH_CONTROL_ACTIONS.has(action) || READ_ACTIONS.has(action)
    || ['play_daily', 'search_and_play', 'prepare_index', 'play_index', 'seek', 'volume', 'stop', 'next', 'previous'].includes(action);
}
