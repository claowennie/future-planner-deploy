import assert from 'node:assert/strict';
import test from 'node:test';
import {
  cleanArtistMatch, isAllowedAction, isNcmLoginActive, normalizePlaybackVolume, parseCliJson, selectPlayableTrack, selectPlayableTracks,
  selectPublicPlaylists, titleHit, waitForPlayerStart,
} from '../src/ncm-cli.mjs';

test('only exposes the intended music action whitelist', () => {
  for (const action of [
    'play_daily', 'search_and_play', 'prepare_index', 'play_index', 'pause', 'resume', 'stop', 'next', 'previous',
    'seek', 'volume', 'list_playlists', 'taste_sample',
  ]) {
    assert.equal(isAllowedAction(action), true);
  }
  for (const action of ['login', 'configure', 'queue', 'shell', 'rm']) {
    assert.equal(isAllowedAction(action), false);
  }
});

test('exposes only safe playlist metadata', () => {
  const result = selectPublicPlaylists({ data: { records: [{
    id: 'A'.repeat(32), name: 'My mix', trackCount: 42, privateField: 'secret',
  }] } }, 'created');
  assert.deepEqual(result, [{ id: 'A'.repeat(32), name: 'My mix', trackCount: 42, source: 'created' }]);
});

test('selects the first visible playable song from search and daily shapes', () => {
  const unavailable = { id: '0'.repeat(32), originalId: 1, playFlag: false, visible: true };
  const playable = { id: 'A'.repeat(32), originalId: 2, playFlag: true, visible: true, name: 'Song' };
  assert.equal(selectPlayableTrack({ data: { records: [unavailable, playable] } }), playable);
  assert.equal(selectPlayableTrack({ data: [unavailable, playable] }), playable);
  assert.deepEqual(selectPlayableTracks({ data: [unavailable, playable] }), [playable]);
});

test('prefers exact artist and title instead of a same-title cover account', () => {
  const cover = {
    id: 'B'.repeat(32), originalId: 3, playFlag: true, visible: true,
    name: 'Yellow', artists: [{ name: 'Coldplay的小迷妹' }],
  };
  const original = {
    id: 'C'.repeat(32), originalId: 4, playFlag: true, visible: true,
    name: 'Yellow', artists: [{ name: 'Coldplay' }],
  };
  const payload = { data: { records: [cover, original] } };
  assert.equal(selectPlayableTrack(payload, { title: 'Yellow', artist: 'Coldplay' }), original);
  assert.equal(selectPlayableTrack({ data: [cover] }, { title: 'Yellow', artist: 'Coldplay' }), null);
  assert.equal(cleanArtistMatch('G.E.M.邓紫棋', [{ name: '邓紫棋' }]), true);
  assert.equal(cleanArtistMatch('王力宏', [{ name: '王力宏的小迷妹' }]), false);
  assert.equal(titleHit('Yellow', 'Yellow (Live)'), true);
});

test('parses uncolored CLI JSON and rejects logs', () => {
  assert.deepEqual(parseCliJson('{"code":200,"data":[]}'), { code: 200, data: [] });
  assert.throws(() => parseCliJson('not json'));
});

test('recognizes only an explicit successful NetEase login check', () => {
  assert.equal(isNcmLoginActive({ success: true, message: 'ok' }), true);
  assert.equal(isNcmLoginActive({ success: false, message: 'expired' }), false);
  assert.equal(isNcmLoginActive({}), false);
});

test('accepts only a safe 0-100 playback volume', () => {
  assert.equal(normalizePlaybackVolume(0), 0);
  assert.equal(normalizePlaybackVolume('58.6'), 59);
  assert.equal(normalizePlaybackVolume(100), 100);
  assert.throws(() => normalizePlaybackVolume(-1), /0 到 100/);
  assert.throws(() => normalizePlaybackVolume(101), /0 到 100/);
  assert.throws(() => normalizePlaybackVolume('loud'), /0 到 100/);
});

test('waits through a stale paused snapshot after playback starts', async () => {
  const states = [
    { status: 'paused', position: 0, duration: 0 },
    { status: 'playing', position: 1, duration: 229 },
  ];
  let reads = 0;
  const state = await waitForPlayerStart(async () => {
    const next = states[Math.min(reads, states.length - 1)];
    reads += 1;
    return next;
  }, { attempts: 4, delayMs: 0 });
  assert.equal(reads, 2);
  assert.equal(state.status, 'playing');
  assert.equal(state.duration, 229);
});


test('accepts CLI 0.1.6 update notices around successful and expired login JSON', () => {
  const notice = '\u001b[33m│ 有新版本: 0.1.6 → 0.1.7  运行 ncm-cli upgrade 升级\u001b[0m\n\n';
  for (const success of [true, false]) {
    const parsed = parseCliJson(notice + JSON.stringify({ success, message: 'login check' }, null, 2));
    assert.equal(isNcmLoginActive(parsed), success);
  }
  const payload = { data: [{ name: 'Song } [ "quoted" \\ title', artists: [] }] };
  assert.deepEqual(parseCliJson(notice + JSON.stringify(payload, null, 2) + '\nUpdate available'), payload);
  assert.deepEqual(parseCliJson(notice + '[{"name":"Song"}]'), [{ name: 'Song' }]);
  assert.throws(() => parseCliJson(notice), { code: 'invalid_ncm_json' });
  assert.throws(() => parseCliJson('notice\n{"data":\n {"success":true}'), { code: 'invalid_ncm_json' });
});

test('setup check exits unsuccessfully for a zero-exit CLI reporting logged out', async () => {
  const fs = await import('node:fs/promises');
  const os = await import('node:os');
  const path = await import('node:path');
  const { spawnSync } = await import('node:child_process');
  const { fileURLToPath } = await import('node:url');
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'future-login-test-'));
  try {
    const entry = path.join(dir, 'cli.cjs');
    for (const success of [false, true]) {
      await fs.writeFile(entry, `console.log('│ Update available\\n'); console.log(${JSON.stringify(JSON.stringify({ success }))});`);
      const result = spawnSync(process.execPath, [fileURLToPath(new URL('../src/setup.mjs', import.meta.url)), 'check'], {
        encoding: 'utf8', windowsHide: true, env: { ...process.env, NCM_CLI_ENTRY: entry },
      });
      assert.equal(result.status, success ? 0 : 1, result.stderr);
      assert.match(result.stdout, success ? /verified/ : /not signed in/);
    }
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});


test('prepares and starts a track when every CLI response has an upgrade notice', async () => {
  const fs = await import('node:fs/promises');
  const os = await import('node:os');
  const path = await import('node:path');
  const { spawnSync } = await import('node:child_process');
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'future-playback-test-'));
  try {
    const entry = path.join(dir, 'cli.cjs');
    const runner = path.join(dir, 'runner.mjs');
    const pidPath = path.join(dir, 'daemon.pid');
    await fs.writeFile(entry, `
      const command = process.argv[2];
      const track = { id: 'A'.repeat(32), originalId: '123', playFlag: true, name: 'Song', artists: [{name:'Artist'}] };
      const payload = command === 'login' ? {success:true}
        : command === 'search' ? {data:{records:[track]}}
        : command === 'state' ? {state:{status:'playing',title:'Song - Artist',position:1,duration:200}}
        : {success:true};
      console.log('│ 有新版本: 0.1.6 → 0.1.7');
      console.log(JSON.stringify(payload));
    `);
    await fs.writeFile(runner, `
      import assert from 'node:assert/strict';
      import fs from 'node:fs';
      import {executeMusicAction} from ${JSON.stringify(new URL('../src/ncm-cli.mjs', import.meta.url).href)};
      fs.writeFileSync(process.env.NCM_CLI_DAEMON_PID, String(process.pid));
      const prepared = await executeMusicAction('search_and_play', 'Song Artist', [], {
        deferPlayback:true, selections:[{title:'Song',artist:'Artist',query:'Song Artist'}],
      });
      assert.equal(prepared.tracks.length,1);
      assert.equal(prepared.state.status,'paused');
      const started = await executeMusicAction('play_index','',[],{index:0,volume:70});
      assert.equal(started.state.status,'playing');
      assert.equal(started.state.title,'Song');
      assert.equal(started.state.duration,200);
    `);
    const result = spawnSync(process.execPath, [runner], {
      encoding:'utf8', windowsHide:true,
      env:{...process.env, NCM_CLI_ENTRY:entry, NCM_CLI_DAEMON_PID:pidPath},
    });
    assert.equal(result.status,0,result.stderr);
  } finally {
    await fs.rm(dir,{recursive:true,force:true});
  }
});
