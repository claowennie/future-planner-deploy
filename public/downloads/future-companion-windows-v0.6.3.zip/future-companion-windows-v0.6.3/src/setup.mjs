import { spawnSync } from 'node:child_process';
import { isNcmLoginActive, parseCliJson, resolveNcmCliEntry, runNcmCli } from './ncm-cli.mjs';

const ACTIONS = Object.freeze({
  configure: ['configure'],
  login: ['login'],
  check: ['login', '--check', '--output', 'json'],
});

const action = String(process.argv[2] || '').trim().toLowerCase();

try {
  const entry = resolveNcmCliEntry();
  if (action === 'locate') process.exit(0);
  if (action === 'check') {
    const payload = parseCliJson(await runNcmCli(ACTIONS.check));
    const loggedIn = isNcmLoginActive(payload);
    console.log(loggedIn ? 'NetEase sign-in verified.' : 'NetEase is not signed in. Run login-companion.cmd and scan again.');
    process.exit(loggedIn ? 0 : 1);
  }

  const args = ACTIONS[action];
  if (!args) {
    console.error('Usage: node src/setup.mjs <configure|login|check|locate>');
    process.exit(2);
  }

  const result = spawnSync(process.execPath, [entry, ...args], {
    stdio: 'inherit',
    windowsHide: false,
    env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1' },
  });
  if (result.error) throw result.error;
  process.exit(Number.isInteger(result.status) ? result.status : 1);
} catch (error) {
  console.error(error?.message || String(error));
  process.exit(1);
}
